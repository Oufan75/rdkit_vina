modlist = [
("ViewerFramework","customizationCommands","""
This module implements a set of class to customize a ViewerFramework
application:
    SetUserPreference
    SetOnAddObjectCmds
"""),
("ViewerFramework","customizeVFGUICommands","""
This Module implements commands 
	to change the appearance of the ViewerFrameworkGUI
 
"""),
("ViewerFramework","dejaVuCommands","""
This module implements classes relative to DejaVu.
"""),
("ViewerFramework","documentationCommands","""
Module implementing classes to provide documentation on the application
"""),
("ViewerFramework","serverCommands","""
This module implements classes to start a server and to connect to a server.
"""),
]
