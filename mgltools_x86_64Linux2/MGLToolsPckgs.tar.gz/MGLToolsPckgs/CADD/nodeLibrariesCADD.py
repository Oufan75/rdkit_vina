########################################################################
#########################################################################
# $Header: /mnt/raid/services/cvs/CADD/nodeLibrariesCADD.py,v 1.2 2011/01/18 00:56:07 nadya Exp $
# $Id: nodeLibrariesCADD.py,v 1.2 2011/01/18 00:56:07 nadya Exp $

libraries = {
 'stdlib': ('Vision.StandardNodes',[]) 
 }

