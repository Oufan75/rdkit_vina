self.bindCmdToKey("F1","None", self.displayCPK,(self.allAtoms[:10],))
self.bindCmdToKey("F2","None", self.displayCPK,(self.allAtoms[:10],), {'negate':True})
