FlagCheck = 1
packageContainsVFCommands = 1

CRITICAL_DEPENDENCIES = ['FlexTree', 'mglutil', 'numpy', 'AutoDockTools',
                         'memoryobject', 'cAutoDock']

NONCRITICAL_DEPENDENCIES = ['MMTK', 'MolKit', 'Pmw', 'ViewerFramework',
                            'PyBabel', 'AutoDockSuite', 'DejaVu',
                            'NetworkEditor', 'Vision', 'opengltk']
